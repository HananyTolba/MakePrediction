#!/usr/bin/env python
# -*- coding: utf-8 -*-
#Author = "Hanany Tolba"
#01/07/2020

__author__ = "Hanany Tolba"
__copyright__ = "Copyright 2020, MakePrediction a Guassian Process as Deep Learning Model Project"
__credits__ = "Hanany Tolba"
__license__ = "GPLv3"
__version__ ="1.0.0"
__maintainer__ = "Hanany Tolba"
__email__ = "hananytolba@yahoo.com"
__status__ = "4 - Beta"



