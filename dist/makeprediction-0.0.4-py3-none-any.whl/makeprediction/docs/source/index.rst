

Welcome to gpasdnn's documentation!
===================================

To install gpasdnn:
-------------------

	GPasDNN can be installed by cloning the repository and running in the root folder:
	* pip install . 
	This also installs required dependencies including TensorFlow, and sets everything up. Or with:
	* pip install gpasdnn 




.. toctree::
   :maxdepth: 2
   :caption: Contents:


   GaussianProcessForTimeSeriesPrediction.ipynb

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
