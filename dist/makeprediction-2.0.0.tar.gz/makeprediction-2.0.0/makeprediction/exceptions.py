


class NotFittedError(Exception):
	pass
