#!/usr/bin/env python
# -*- coding: utf-8 -*-
#Author = "Hanany Tolba"
#01/07/2020

__author__ = "Hanany Tolba"
__copyright__ = "Copyright 2021, MakePrediction: a Guassian Process for time series prediction Project"
__credits__ = "Hanany Tolba"
__license__ = "GPLv3"
__version__ ="2.0.0"
__maintainer__ = "Hanany Tolba"
__email__ = "hananytolba@yahoo.com"
__status__ = "4 - Beta"



